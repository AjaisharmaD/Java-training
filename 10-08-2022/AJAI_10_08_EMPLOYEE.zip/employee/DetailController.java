/*
 * This is program which is used to set the employees details
 * and getting the Employees name 
 * by giving some critaria
 * @author AJAISHARMA
 */

import java.util.Scanner;

/*
 * Controls of this System goes in here
 * getting the input from the user 
 *
 */
public class DetailController {
    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	String name;
	int experience;
	float salary;
	int noOfEmployees = scanner.nextInt();
	DetailRecorder[] records = new DetailRecorder[noOfEmployees];
	System.out.println("Enter the number to process the operations\n" 
				+ " 1.Add Employee Details\n " 
				+ " 2.Top 5 experienced Employees\n"
				+ " 3.Top 5 Paid Employees\n"
				+ " 4.Hieghest Experienced Employee\n" );
	
	for(int index = 0; index < noOfEmployees; index++) {
	    records[index] = new DetailRecorder();
	    name = scanner.nextLine();
	    records[index].setEmployeeName(name);    
	}
    }
}