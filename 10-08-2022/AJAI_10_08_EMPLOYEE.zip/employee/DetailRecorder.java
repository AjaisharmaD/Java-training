/*
 * This class is used to set and get the details of the Employees
 * @author AJAISHARMA D
 * version 1.0
 *
 */

public class DetailRecorder {
    private String employeeName;
    private int employeeExperience;
    private float employeeSalary;
    
    public void setEmployeeName(String name) {
	employeeName = name ;
    }
/*
    public void setEmployeeExperience(int experience) {
	employeeExperience = experience;
    }

    public void setEmployeeSalary(float salary) {
	employeeSalary = salary;
*/
     String getEmployeeName() {
	return employeeName;
    }
/*
    public int getEmployeeExperience() {
	return employeeExperience;
    }

    public float getEmployeeSalary() {
	return employeeSalary;
    }
*/
}
