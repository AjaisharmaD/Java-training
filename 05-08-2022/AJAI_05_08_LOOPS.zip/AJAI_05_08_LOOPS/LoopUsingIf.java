class LoopUsingIf {
    public static void main (String[] args) {
	int a=1;
	if(a<5){
	    System.out.println(a);
	    a++;
	}
    }
} 