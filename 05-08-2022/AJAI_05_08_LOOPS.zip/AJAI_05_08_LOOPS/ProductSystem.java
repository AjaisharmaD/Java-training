import java.util.Scanner;

class ProductSystem {
    /*public int addProduct() {
    
    }

    public displayProduct() {

    }

    public saleCount() {

    }*/
    public static void main(String[] args) {
	Scanner getInput = new Scanner(System.in);
	System.out.println("enter the no of product ");
	int noOfProduct = getInput.nextInt();
	
        
	
	
    }
}